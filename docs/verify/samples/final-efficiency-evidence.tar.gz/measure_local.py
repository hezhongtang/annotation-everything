import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ARTIFACTS=Path('/private/tmp/ae-final-49-57-evidence')
FINAL=Path('/private/tmp/ae-final-49-57-20261102')
sys.path.insert(0,str(FINAL))
import host_isolation as hi
plan=json.loads((ARTIFACTS/'final-plan.json').read_text())
results=json.loads((ARTIFACTS/'local-results.json').read_text())['samples']
for label, folder in [('candidate','ae-final57-local-candidate')]:
    work=Path('/private/tmp')/folder
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
    if head!=plan[label]:raise RuntimeError('experiment input does not match fixed plan')
    out=ARTIFACTS/'local'/label
    out.mkdir(parents=True,exist_ok=True)
    env=dict(os.environ,AE_HOME=str(ARTIFACTS/'local'/'ae-home'),UV_OFFLINE='1')
    env.pop(hi.HELD_ENV,None)
    held=hi.acquire(['host-state'],env=env)
    try:
        cases=[{'id':'cleanup','path':None}]+plan['local_cases']
        for case in cases:
            path=work/case['path'] if case['path'] else None
            before=path.read_bytes() if path else None
            try:
                if path:
                    suffix=b'\n  \n' if path.suffix=='.json' else b'\n# Synthetic final acceptance timing probe.\n'
                    path.write_bytes(before+suffix)
                    p=subprocess.run([sys.executable,'verify.py','plan','--phase','development','--baseline',head,'--json'],cwd=work,env=env,capture_output=True,text=True,check=True,pass_fds=held.file_descriptors())
                    selection=json.loads(p.stdout)['selection']
                    if selection['fallback'] is not None:raise RuntimeError(selection['fallback'])
                    selectors=selection['suggested'].get('selectors_effective') or selection['suggested']['selectors']
                    (out/(case['id']+'.plan.json')).write_text(p.stdout)
                else:
                    selectors=['tests/test_e2e_servers.py']
                for sample in range(1,4):
                    started=time.monotonic()
                    with (out/(case['id']+f'-{sample}.stdout.log')).open('w') as log:
                        done=subprocess.run([sys.executable,'verify.py','run','unit-related',*selectors,'--issue','57','--phase','development','--baseline',head,'--reason',f"Fixed synthetic local experiment {case['id']} {label} sample {sample}/3",'--no-reuse','--quiet','--out-dir',str(out)],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,pass_fds=held.file_descriptors())
                    wall=time.monotonic()-started
                    run_id=json.loads((out/'latest.json').read_text())['run_id']
                    record=out/'runs'/run_id/'record.json'
                    r=json.loads(record.read_text())
                    item={'phase':label,'case':case['id'],'sample':sample,'head':head,'run_id':run_id,'exit_status':done.returncode,'cli_wall_seconds':round(wall,6),'record_wall_seconds':r['timing']['wall_seconds'],'first_feedback_seconds':r['timing']['first_feedback_seconds'],'lock_wait_seconds':r['timing']['lock_wait_seconds'],'coordinator_lock_wait_seconds':held.waited_seconds,'counts':r['result']['counts'],'fingerprint':r['input']['fingerprint'],'covers_final_input':r['input']['covers_final_input'],'record_sha256':hashlib.sha256(record.read_bytes()).hexdigest()}
                    results.append(item)
                    (ARTIFACTS/'local-results.json').write_text(json.dumps({'schema':'ae-local-acceptance-results/1','plan':'final-plan.json','samples':results},ensure_ascii=False,indent=2)+'\n')
                    print(json.dumps(item,ensure_ascii=False),flush=True)
                    if done.returncode or not r['input']['covers_final_input']:raise RuntimeError('local acceptance failed; original evidence retained')
            finally:
                if path:path.write_bytes(before)
        if label == 'baseline':
            with (ARTIFACTS/'baseline-browser-final.stdout.log').open('w') as log:
                done=subprocess.run([sys.executable,'verify.py','run','--group','browser','--issue','57','--phase','development','--no-reuse','--quiet','--out-dir',str(ARTIFACTS/'baseline')],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,pass_fds=held.file_descriptors())
            if done.returncode: raise RuntimeError('Baseline browser failed; original evidence retained')
            print('Additional whole-success baseline browser sample complete',flush=True)
        if label == 'candidate':
            for sample in range(1,4):
                with (ARTIFACTS/f'final-candidate-{sample}.stdout.log').open('w') as log:
                    done=subprocess.run([sys.executable,'verify.py','run','--group','all','--issue','57','--phase','development','--reason',f'Fixed final candidate performance sample {sample}/3','--no-reuse','--quiet','--out-dir',str(ARTIFACTS/'final-candidate')],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,pass_fds=held.file_descriptors())
                if done.returncode: raise RuntimeError('Candidate full acceptance failed; original evidence retained')
                print(f'Final candidate full sample {sample}/3 complete',flush=True)
    finally:
        hi.release(held,env)
