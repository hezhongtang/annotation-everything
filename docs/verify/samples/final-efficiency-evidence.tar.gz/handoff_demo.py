import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/private/tmp/ae-final-49-57-evidence')
WORK=Path('/private/tmp/ae-final57-local-candidate')
OUT=ROOT/'handoff-demo'
env=dict(os.environ,UV_OFFLINE='1',AE_HOME=str(ROOT/'handoff-ae-home'),AE_VERIFY_SESSION='issue57-final-synthetic-handoff-20261102')
summary=[]
for phase,expected in [('development','run'),('review','reuse'),('manual','reuse')]:
    OUT.mkdir(exist_ok=True)
    with (OUT/(phase+'.stdout.log')).open('w') as log:
        subprocess.run([sys.executable,'verify.py','run','--group','serve-check','--phase',phase,'--issue','57','--reason','Synthetic same-input handoff; manual phase prepares PR evidence; final PR gate executes separately','--quiet','--out-dir',str(OUT)],cwd=WORK,env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
    run_id=json.loads((OUT/'latest.json').read_text())['run_id']
    r=json.loads((OUT/'runs'/run_id/'record.json').read_text())
    assert r['result']['usable_as_evidence'] and r['input']['covers_final_input']
    assert r['reuse']['decisions'][0]['decision']==expected,r['reuse']
    summary.append({'phase':phase,'run_id':run_id,'decision':expected,'fingerprint':r['input']['fingerprint']})
assert len({r['fingerprint'] for r in summary})==1
with (OUT/'report-latest.txt').open('w') as log:
    subprocess.run([sys.executable,'verify.py','report','--latest','--out-dir',str(OUT)],cwd=WORK,env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
with (OUT/'report-efficiency.txt').open('w') as log:
    subprocess.run([sys.executable,'verify.py','report','--efficiency','--out-dir',str(OUT)],cwd=WORK,env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
(ROOT/'handoff-summary.json').write_text(json.dumps({'schema':'ae-final-handoff-demo/1','scope':'Synthetic serve-check only; PR and CI gates execute separately','actual_group_executions':1,'group_references':2,'repeated_full_runs':0,'runs':summary},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
